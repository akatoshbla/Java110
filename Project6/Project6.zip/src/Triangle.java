/**
* Project #6: Polymorphism and Inheritance
* File: Triangle.java
* Section #14492
* Programmer: David Kopp
* Date: 4/17/13
* Description: This program is a templete for a triangle with a base and height parameter.
*/

import java.awt.*;

   public class Triangle extends Shape {
   
   // Variables:
      private int base;
      private int height;
   
   // Methods:
   
   // Constructor with no args
      public Triangle() {
         super();
         base = 1;
         height = 1;
      
      }
   
   // Constructor with parameters
      public Triangle(int x, int y, int newBase, int newHeight) {
         super(x, y);
         setBase(newBase);
         setHeight(newHeight);
      
      }
   
   // Set Base and Height methods
      public int getBase() {
         return base;
      
      }
   
      public int getHeight() {
         return height;
      
      }
   
   // Get Base and Height methods
      public void setBase(int newBase) {
         if (newBase > 0) {
            base = newBase;
         
         }
         
         else {
            System.out.println("The base " + base + " entered is incorrect. (Please enter a base greater than 0.)");
         
         }
      
      }
   
      public void setHeight(int newHeight) {
         if (newHeight > 0) {
            height = newHeight;
         
         }
         
         else {
            System.out.println("The height " + height + " entered is incorrect. (Please enter a height greater than 0.)");
         
         }
      
      }
   
      public void display() {
         System.out.println("This shape is a Triangle at " + getX() + ", " + getY() + " with a base of " + base +" and a height of " + height + ".");
      
      }
   
      public double area() {
         return (base * height) / 2;
      
      }
   
		public void display(Graphics g) {
         g.drawLine(getX(), getY() + height, getX() + base / 2, getY()); 
      	g.drawLine(getX(), getY() + height, getX() + base, getY() + height);
			g.drawLine(getX() + base / 2, getY(), getX() + base, getY() + height);
			
      }
	
   }