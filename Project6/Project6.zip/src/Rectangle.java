/**
* Project #6: Polymorphism and Inheritance
* File: Rectangle.java
* Section #14492
* Programmer: David Kopp
* Date: 4/17/13
* Description: This program is a templete for a rectangle with a width and height parameter. 
*/

   import java.awt.*;

   public class Rectangle extends Shape {
   
   // Variables:
      private int width;
      private int height;
   
   // Methods:
   
   // Constructor with no args
      public Rectangle() {
         super();
         width = 1;
         height = 1;
      
      }
   // Constructor with parameters
      public Rectangle(int x, int y, int newWidth, int newHeight) {
         super(x, y);
         setWidth(newWidth);
         setHeight(newHeight);
      
      }
   
   // Get Width and Height Method
      public int getWidth() {
         return width;
      
      }
   
      public int getHeight() {
         return height;
      
      }
   
   // Set Width and Height Method
      public void setWidth(int newWidth) {
         if (newWidth > 0) {
            width = newWidth;
         
         }
         
         else {
            System.out.println("The width " + width + " entered is incorrect. (Please enter a width greater than 0.)");
         
         }
      
      }
   
      public void setHeight(int newHeight) {
         if (newHeight > 0) {
            height = newHeight;
         
         }
         
         else {
            System.out.println("The height " + height + " entered is incorrect. (Please enter a height greater than 0.)");
         
         }
      
      }
   
      public void display() {
         System.out.println("This shape is a Rectangle at " + getX() + ", " + getY() + " with a width of " + width + " and a height of " + height + ".");
      
      }
   
      public double area() {
         return width * height;
      
      }
   	
      public void display(Graphics g) {
         g.drawRect(getX(), getY(), width, height); 
      
      }
   
   }