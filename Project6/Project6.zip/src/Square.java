/**
* Project #6: Polymorphism and Inheritance
* File: Rectangle.java
* Section #14492
* Programmer: David Kopp
* Date: 4/17/13
* Description: This program is a templete for a rectangle with a width and height parameter. 
*/

   public class Square extends Rectangle {
   
   // Constructor with no parameters
      public Square() {
         super();
      
      }
   
   // Constructor with parameters
      public Square(int x, int y, int newWidth, int newHeight) {
         super(x, y, newWidth, newHeight);
         setWidth(newWidth);
         setHeight(newHeight);
      
      }
   
   // Set method for width
      public void setWidth(int newWidth) {
         super.setHeight(newWidth);
         super.setWidth(newWidth);
      
      }
   
   // Set method for height
      public void setHeight(int newHeight) {
         super.setWidth(newHeight);
			super.setHeight(newHeight);
      
      }
   
   // Override to Rectangles Display
      public void display() {
         System.out.println("This shape is a Square at " + getX() + ", " + getY() + " with a width of " + super.getWidth() + " and a height of " + super.getHeight() + ".");
      
      }
   
   }