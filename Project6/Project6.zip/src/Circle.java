/**
* Project #6: Polymorphism and Inheritance
* File: Circle.java
* Section #14492
* Programmer: David Kopp
* Date: 4/17/13
* Description: This program is a templete for a circle with a radius parameter.
*/

   import java.awt.*;

   public class Circle extends Shape {
   
   // Variables
      private int radius;
   
   // Methods
   
   // Constructor with no parameters
      public Circle() {
         super();
         radius = 1;
      
      }
   
   // Constructor with parameters
      public Circle(int x, int y, int newRadius) {
         super(x, y);
         setRadius(newRadius);
      
      }
   
   // Get radius method
      public int getRadius() {
         return radius;
      
      }
   
   // Set radius method
      public void setRadius(int newRadius) {
         if (newRadius > 0) {
            radius = newRadius;
         
         }
         
         else {
            System.out.println("The radius " + radius + " entered has to be greater than 0. (Radius value has to be an integer.)");
         
         }
      
      }
   
      public void display() {
         System.out.println("This shape is a Circle at " + getX() + ", " + getY() + " and has a radius of " + radius + ".");
      
      }
   
      public double area() {
         return radius * radius * Math.PI;
      
      }  
   	
      public void display(Graphics g) {
         g.drawOval(getX(), getY(), 2*radius, 2*radius); 
      
      }
   	 
   }