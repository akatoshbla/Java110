/**
* Project #6: Polymorphism and Inheritance
* File: Project6.java
* Section #14492
* Programmer: David Kopp
* Date: 4/17/13
* Description: This program creates different shapes and sets the parameters of each object. 
*/

   import javax.swing.*;
   import java.awt.*;
	
   public class Project6 extends JFrame {
   
      public Project6() {
         JFrame frame = new JFrame("Shapes");
         MyPanel panel1 = new MyPanel();
         frame.add(panel1);
         frame.setSize(400,300);
         frame.setVisible(true);
         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      }
   	
      public class MyPanel extends JPanel {
         public void paintComponent(Graphics g) {
            super.paintComponent(g);
         
            for(Shape s : thearray) {
               if(s != null) {
                  s.display(g);
               }
            }
         
            repaint();
         }
      }
         
      private Shape [] thearray = new Shape[100];  // 100 Shapes, circle's, tri's and rects
   
      public static void main (String [] args) {
         Project6 tpo = new Project6();
         tpo.run();
      }  // end of main
   
      public void run () {
         int count = 0;
      
      // ------------------------   Fill the array section ----------------------
         thearray[count++] = new Circle(20, 40, 40);
			
			thearray[count++] = new Circle(300, 40, 40);
      
         thearray[count++] = new Triangle(50, 145, 20, 30);
			
			thearray[count++] = new Triangle(50, 195, 20, 30);
			
			thearray[count++] = new Triangle(50, 235, 20, 30);
			
			thearray[count++] = new Triangle(330, 145, 20, 30);
			
			thearray[count++] = new Triangle(330, 195, 20, 30);
			
			thearray[count++] = new Triangle(330, 235, 20, 30);
			
			thearray[count++] = new Triangle(180, 90, 40, 50);
      
         thearray[count++] = new Rectangle(127, 155, 140, 50);
			
			thearray[count++] = new Rectangle(20, 5, 80, 20);
			
			thearray[count++] = new Rectangle(300, 5, 80, 20);
      	
         thearray[count++] = new Square(317, 95, 12, 12);
			
			thearray[count++] = new Square(70, 95, 12, 12);
      // ------------------------------  array fill done ------------------------
      
      //---------------------------  loop through the array  --------------------
         for (int i = 0; i < count; i ++ ) {    // loop through all objects in the array
         
            thearray[i].display();              // don?t care what kind of object, display it
         
         }  // end for loop
      
         int offset = 0;
      
         double totalarea = 0.0;
      
         while (thearray[offset] != null) {          // loop through all objects in the array
         
            totalarea = totalarea + thearray[offset].area();   // get area for this object
         
            offset++;
         
         } // end while loop
      
         System.out.println("The total area for " + offset + " Shape objects is " + totalarea);
      }  // end of run
   					
   }  // end of class Project6