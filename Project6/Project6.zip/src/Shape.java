/**
* Project #6: Polymorphism and Inheritance
* File: Shape.java
* Section #14492
* Programmer: David Kopp
* Date: 4/17/13
* Description: This program is an abstract parent class that includes an x and y get'ers and set'ers. 
* In addition, this class also has two abstract methods display and area.
*/

   import java.awt.*;

   public abstract class Shape {
   
   // Variables
      private int x;
      private int y;
      protected final static int X_MAX_SIZE = 800;
      protected final static int Y_MAX_SIZE = 600;
   	   
   // Constructor with no parameters
      public Shape() {
         x = 0;
         y = 0;
      
      }
   
   // Constructor with parameters
      public Shape(int newX, int newY) {
         setX(newX);
         setY(newY);
      
      }
   
   // Get methods
      public int getX() {
         return x;
      
      }
   
      public int getY() {
         return y;
      
      }
   
   // Set methods
      public void setX(int newX) {
         if (newX >= 0 && newX <= X_MAX_SIZE) {
            x = newX;
         
         }
         
         else {
            System.out.println("The value of " + newX + " for x is outside the intended rage. (Acceptable Range for x is 0-800)");
         
         }		
      
      }
   	
      public void setY(int newY) {
         if (newY >= 0 && newY <= Y_MAX_SIZE) {
            y = newY;
         
         }
         
         else {
            System.out.println("The value of " + newY + " for y is outside the intended rage. (Acceptable Range for y is 0-600)");
         
         }
      
      }
   
   // Abstract methods
      public abstract void display();
      public abstract double area();
      public abstract void display(Graphics g);  
   
   }