/**
* Project #1: Draw Diamond
* File: DrawDiamond.java
* Section #14493
* Programmer: David Kopp
* Date: 1/28/13
* Description: This program will print out a Diamond shape using * and println.
*/

   public class DrawDiamond{
      public static void main(String[] args){
      
         System.out.println("    *");
         System.out.println("   ***");
         System.out.println("  *****");
         System.out.println(" *******");
         System.out.println("*********");
         System.out.println(" *******");
         System.out.println("  *****");
         System.out.println("   ***");
         System.out.println("    *");  
      }
   }