/**
* Project #1: Name Initials
* File: MyInitials.java
* Section #14493
* Programmer: David Kopp
* Date: 1/28/13
* Description: This program will print out my initials to my name D K in a pattern.
*/

   public class MyInitials{
      public static void main(String[] args){
		
         System.out.println("DDDDDD      K      K");
         System.out.println("D     D     K    K");
         System.out.println("D      D    K   K");
         System.out.println("D      D    K K");
         System.out.println("D      D    K K");
         System.out.println("D      D    K   K");
         System.out.println("D     D     K    K");
         System.out.println("DDDDDD      K      K");	
      }
   }